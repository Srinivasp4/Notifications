export const environment = {
  production: true,
  firebase: {
  	apiKey: "AIzaSyAdT0hXNp893zhka5lofmg1rBLr1Ll81NM",
	authDomain: "simple-notification-d7166.firebaseapp.com",
	databaseURL: "https://simple-notification-d7166.firebaseio.com",
	projectId: "simple-notification-d7166",
	storageBucket: "simple-notification-d7166.appspot.com",
	messagingSenderId: "307076562027"
  }
};
